#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "esp_timer.h"


#define TRIG_PIN      5
#define ECHO_PIN      18
#define LEFT_MOTOR    26
#define RIGHT_MOTOR   27


#define SAFE_DISTANCE 25
#define STOP_DISTANCE 15
#define BASE_SPEED    150
#define MAX_PWM       255


float Kp = 1.2;
float Ki = 0.02;
float Kd = 0.3;

float error = 0, prev_error = 0, integral = 0;

static void delay_us(uint32_t us) {
    int64_t start = esp_timer_get_time();
    while ((esp_timer_get_time() - start) < us);
}


float read_ultrasonic() {
    gpio_set_level(TRIG_PIN, 0);
    delay_us(2);
    gpio_set_level(TRIG_PIN, 1);
    delay_us(10);
    gpio_set_level(TRIG_PIN, 0);

    while (gpio_get_level(ECHO_PIN) == 0);
    int64_t start = esp_timer_get_time();
    while (gpio_get_level(ECHO_PIN) == 1);
    int64_t end = esp_timer_get_time();

    float duration = end - start;
    return (duration * 0.034f) / 2.0f;
}


void set_motor(int l, int r) {
    ledc_set_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_0, l);
    ledc_update_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_0);

    ledc_set_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_1, r);
    ledc_update_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_1);
}


void pid_control(float distance) {
    error = SAFE_DISTANCE - distance;

    integral += error;
    if (integral > 200) integral = 200;
    if (integral < -200) integral = -200;

    float derivative = error - prev_error;
    prev_error = error;

    float pid = Kp * error + Ki * integral + Kd * derivative;
    if (pid > 100) pid = 100;
    if (pid < -100) pid = -100;

    int left = BASE_SPEED + pid;
    int right = BASE_SPEED - pid;

    if (left < 0) left = 0;
    if (right < 0) right = 0;
    if (left > MAX_PWM) left = MAX_PWM;
    if (right > MAX_PWM) right = MAX_PWM;

    set_motor(left, right);

    printf("Dist: %.2f | Err: %.2f | PID: %.2f | L:%d R:%d\n",
           distance, error, pid, left, right);
}


void control_task(void *arg) {
    while (1) {
        float d = read_ultrasonic();

        if (d < STOP_DISTANCE) {
            set_motor(0, 0);
            printf("STOP – obstacle close\n");
        } else {
            pid_control(d);
        }

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}


void app_main(void) {
    gpio_set_direction(TRIG_PIN, GPIO_MODE_OUTPUT);
    gpio_set_direction(ECHO_PIN, GPIO_MODE_INPUT);

    ledc_timer_config_t timer = {
        .speed_mode = LEDC_HIGH_SPEED_MODE,
        .timer_num = LEDC_TIMER_0,
        .freq_hz = 5000,
        .duty_resolution = LEDC_TIMER_8_BIT
    };
    ledc_timer_config(&timer);

    ledc_channel_config_t left = {
        .gpio_num = LEFT_MOTOR,
        .speed_mode = LEDC_HIGH_SPEED_MODE,
        .channel = LEDC_CHANNEL_0,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0
    };
    ledc_channel_config(&left);

    ledc_channel_config_t right = {
        .gpio_num = RIGHT_MOTOR,
        .speed_mode = LEDC_HIGH_SPEED_MODE,
        .channel = LEDC_CHANNEL_1,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0
    };
    ledc_channel_config(&right);

    xTaskCreate(control_task, "control", 4096, NULL, 5, NULL);
}
